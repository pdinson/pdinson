import os, re, sys, string, json, gzip
import views.preprocessing as pps
import views.postprocessing as pos
import views.utils as utils
import views.basic_cltk as basic_cltk
import views.basic_cltk as bc
import word_meanings as word_meaning
from string import digits
from cltk.morphology.universal_dependencies_features import Case
from flask import Flask,render_template,request,redirect
from flask import send_file, jsonify
from numpy import true_divide
from flask import make_response
from cltk import NLP
from cltk.stem import lat
from cltk.alphabet.lat import JVReplacer
from cltk.lemmatize.lat import LatinBackoffLemmatizer
from cltk.prosody.lat.macronizer import Macronizer
from cltk.prosody.lat.hexameter_scanner import  HexameterScanner
from cltk.prosody.lat.pentameter_scanner import PentameterScanner
from cltk.prosody.lat.scanner import Scansion
from cltk.prosody.lat.clausulae_analysis import Clausulae
from cltk.prosody.lat.scansion_formatter import ScansionFormatter
from cltk.stops.words import Stops
from cltk.wordnet.wordnet import WordNetCorpusReader

cltk_nlp = NLP(language="lat")
cltk_nlp.pipeline.processes.pop(-1)
LWN = WordNetCorpusReader(iso_code="lat")
lemmatizer = LatinBackoffLemmatizer()

app = Flask(__name__)
app.config["DEBUG"] = True
#app.run(host='0.0.0.0')

output_filename = "api_output.txt"
macronizer = Macronizer('tag_ngram_123_backoff')
stops_obj = Stops(iso_code="lat")
stopwordlist = stops_obj.get_stopwords()

dialogus_data = ""
dialogus_data1 = ""
preprocessed_data, folder_filelist = pps.preprocess_data()

@app.route('/', methods=['GET', 'POST'])
def home():
    return render_template('webpage.html', preprocessed_data = folder_filelist)

@app.route('/scansion-analysis/',methods=['GET', 'POST'])
def scansionanalysis():
    if request.method == 'POST':
        res = ""
        data = dict()

        selected_tab = request.form.get('user_selected_left_tab');
        if selected_tab == "CorporaText":
            #try
            author = request.form.get('author')
            corporatext = request.form.get('text')
            author1 = request.form.get('author1')
            corporatext1 = request.form.get('text1')

            res = getScancions(request ,author, corporatext)
            data['res'] = res
            data['single_author'] = True

            selected_tab = request.form.get('user_selected_left_tab');
            if selected_tab == "CorporaText" and request.form.get('author1') and request.form.get('text1'):
                res = getScancions(request ,author1, corporatext1)
                data['res2'] = res
                data['single_author'] = False
            # except Exception as e:
                # print(e)
                # data['res'] = "Erro occured while creating scansions"
                # data['single_author'] = True
        elif selected_tab == "UserEnteredEnterText":
            author = "UserEnteredText"
            content = request.form.get('user_entered_text');
            corporatext = bc.apply_cltk(content)
            res = getScancions(request ,author, corporatext)
            data['res'] = res
            data['single_author'] = True
        elif selected_tab == "UploadRawFile":
            content = request.files['file'].read().decode("utf-8")
            if (len(content) > 0): 
                corporatext = bc.apply_cltk(content)
                author = "UserEnteredText"
                res = getScancions(request ,author, corporatext)
                data['res'] = res
                data['single_author'] = True

    return make_response(data, 200)

@app.route('/rhythm-analysis/',methods=['GET', 'POST'])
def rhythm_analysis():
    if request.method == 'POST':
        res = ""
        data = dict()

        selected_tab = request.form.get('user_selected_left_tab');
        if selected_tab == "CorporaText":
            try:
                author = request.form.get('author')
                corporatext = request.form.get('text')
                author1 = request.form.get('author1')
                corporatext1 = request.form.get('text1')

                res = getRhythm(request ,author, corporatext)
                data['res'] = res
                data['single_author'] = True

                if request.form.get('author1') and request.form.get('text1'):
                    res = getRhythm(request ,author1, corporatext1)
                    data['res2'] = res
                    data['single_author'] = False
            except Exception as e:
                data['res'] = "Error occured while creating rhythm"
                data['single_author'] = True
        elif selected_tab == "UserEnteredEnterText":
                content = request.form.get('user_entered_text');
                if (len(content) > 0): 
                    corporatext = bc.apply_cltk(content)
                    author = "UserEnteredText"
                    res = getRhythm(request ,author, corporatext)
                    data['res'] = res
                    data['single_author'] = True

        elif selected_tab == "UploadRawFile":
            content = request.files['file'].read().decode("utf-8")
            if (len(content) > 0): 
                corporatext = bc.apply_cltk(content)
                author = "UserEnteredText"
                res = getRhythm(request ,author, corporatext)
                data['res'] = res
                data['single_author'] = True

    return make_response(data, 200)

#Word Meanings
@app.route('/word-meanings/',methods=['GET', 'POST'])
def word_meanings():
    data = dict()
    word_net = ""
    awnet = ""
    word_for_meaning = str(request.form.get('aWord'))
    whitker_word = "Whitaker: "+ str(word_for_meaning).capitalize() + " <br/>"
     
    try:
        whitker_word  += word_meaning.get_word_meaning(word_for_meaning) + "<br/>"
    except: pass

    try:
        uirtus = LWN.lemma(word_for_meaning)
        for xs in uirtus[0].synsets():
            awnet += "(" + xs.pos() + ") " + xs.gloss().capitalize() + "<br/>"
    except: pass
 
    if len(awnet) > 0:
        word_net = "Wordnet: " + str(word_for_meaning.capitalize()) + "<br/>" + awnet
    
    if len(whitker_word) < 1:
        whitker_word += "Meaning not available"

    data['WhitkerWords'] = whitker_word
    data['wordnet'] = str(word_net)  
    return make_response(data, 200)

#Word Analysis
@app.route('/word-analysis/',methods=['GET', 'POST'])
def word_analysis():
    print("In word Analysis")
    global dialogus_data
    data = get_corpora_data(request)

    #data = '<html> <body> <p> aa</p> </body> </html>' 
    data = gzip.compress(json.dumps(data).encode('utf8'), 5)
    response = make_response(data)
    response.headers['Content-length'] = len(data)
    response.headers['Content-Encoding'] = 'gzip'
    return response

#Word Search
@app.route('/word-search/',methods=['GET', 'POST'])
def word_search():
    if request.method == 'POST':
      data =  get_corpora_data(request)
    return make_response(data, 200)

#Uploaded file
@app.route('/uploadfile/',methods=['GET', 'POST'])
def uploaded_file():
    data = getData(request)
    return make_response(data, 200)

def get_corpora_data(request):
    data = ""
    data1 = ""
    author1 = ""
    corporatext1 = ""

    macronize_chk = request.form.get('macronize_chk')
    remove_words_chk = request.form.get('remove_words_chk')

    global dialogus_data
    global dialogus_data1

    if request.method == 'POST':
        author = request.form.get('author')
        corporatext = request.form.get('text')
        output_data_section = 'AIData'
        exact_word_search = request.form.get('stemorlemmawords');
        if author == "Abelard" and corporatext == "Dialogus" and len(exact_word_search.strip()) < 1 and macronize_chk == "false" and remove_words_chk == "false":
            if len(dialogus_data) > 0:
                data = json.loads(gzip.decompress(dialogus_data))
            else: 
                data = getData(request,author, corporatext,output_data_section)
                dialogus_data = gzip.compress(json.dumps(data).encode('utf8'), 5)              
        else:
            data = getData(request,author, corporatext,output_data_section)

        print(len(data['AIData']))
        data.update({'author': author})
        data.update({'corporatext': corporatext})

        selected_tab = request.form.get('user_selected_left_tab');
        if selected_tab == "CorporaText" and request.form.get('author1') and request.form.get('text1'):
            author1 = request.form.get('author1')
            corporatext1 = request.form.get('text1')
            output_data_section = 'AIData1'

            # Make sure its not a masco or stop words
            # # also check if author ve author1  is selected and 
            if author1 == "Abelard" and corporatext1 == "Dialogus" and macronize_chk == "false" and remove_words_chk == "false":
                if len(dialogus_data1) > 0:
                    data1 =  json.loads(gzip.decompress(dialogus_data1))
                else: 
                    data1 = getData(request,author, corporatext,output_data_section)
                    dialogus_data1 = gzip.compress(json.dumps(data1).encode('utf8'), 5) 
            else:
                data1 = getData(request,author1, corporatext1, output_data_section)

            data.update(data1)
            data.update({'author1': author1})
            data.update({'corporatext1': corporatext1})
    return data

def getRhythm(request, author, corporatext):
    print("Rhythms")
    s = Scansion()
    c = Clausulae()
    invalidcharacters = set(string.punctuation)

    if author == "UserEnteredText":
        corporatext =  basic_cltk.apply_cltk(corporatext)
        cltk_doc_object = cltk_nlp.analyze(text=corporatext)
    else:
        cltk_doc_object = pps.get_doc_content(author.lower(), corporatext.lower())

    remove_digits = str.maketrans('', '', digits)
    allStrings = ""
    for i in cltk_doc_object.sentences:
        aString = ""
        resultTxt = ""
        for x in i.words:
            aString += x.string + " "
                
        aString = aString.translate(remove_digits)
        aString = aString.strip()
        if len(aString) > 0 and  aString[-1] in invalidcharacters:
            aString = aString[:-1].strip()
    
        if len(aString) > 0:
            if aString[:-1] != ".":
                aString = aString + "."
            
            resultTxt = aString #+ "\n"
            resultTxt += "<pre>"

            try:
                prosody = s.scan_text(aString)
                rym_freq_dict = c.clausulae_analysis(prosody)
            except: pass
                            
            resultTxt += "<p style='color:blue;'>prosody : " + str(prosody[0]) if len(prosody) >= 1 else ""
            resultTxt += "\n"
            outString = ""
            for data in rym_freq_dict:
                for key, val in data.items():
                    if val > 0:
                        outString += str(key) + " : " + str(val) + ", "
            
            resultTxt += outString[:-2] + "</p>"
            resultTxt += "</pre>"
            allStrings += resultTxt
    return allStrings

def getScancions(request, author, corporatext):
    print("Scansicons")
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    file = r"corpora\raw" + "\\" + author.lower() + "\\" + corporatext.lower() + ".txt"
    remove_digits = str.maketrans('', '', digits)

    hexameter_chk = request.form.get('hexameter_chk')
    pentameter_chk = request.form.get('pentameter_chk')

    if pentameter_chk == "true":
        s = PentameterScanner()
    else:
        s = HexameterScanner()
    
    verse = ""
    aString = ""
    content = ""
    scaned_string = ""
    if author == "UserEnteredText":
        content = corporatext
    else:
        with open(file, 'r', encoding="utf8") as f:
            content += f.read().translate(remove_digits)
        f.close

    stringlist = content.splitlines()
    outString = "<pre>"
    for aString in stringlist:
        try:
            verse = s.scan(aString.strip())
        except: pass

        resultTxt = "<p style='color:black;'>" 

        if len(str(verse)) > 0:
            scaned_string = str(verse.scansion)

        try:
            if hexameter_chk == "true" and len(str(verse)) > 0:
                resultTxt += ScansionFormatter().merge_line_scansion(aString,scaned_string)
                resultTxt += "\n"
                resultTxt += scaned_string
            else:
                outString += aString + "\n"
                resultTxt += scaned_string
        except Exception as e:
            print(e)
            
        outString += resultTxt[:-2] + " </p>"

    outString += "</pre>"
    return outString

def getData(request, author, corporatext, output_data_section):
    global_ai_data = ''
    #corporatext = ""
    #rawdata = ""
    user_input_lemma = ""
    user_input_stem = ""
    stat_list = {}
    print("Getting Data")
    try:
        ListOfWordsToMark = [] # add words to mark
        selected_words_features = request.form.get('selected_words');
        lemma = request.form.get('lemma');
        stem = request.form.get('stem');
        exact_word_search = request.form.get('stemorlemmawords');
        macronize_chk = request.form.get('macronize_chk')
        remove_words_chk = request.form.get('remove_words_chk')
        user_selected_top_tab = request.form.get('user_selected_top_tab')
        selected_tab = request.form.get('user_selected_left_tab');

        selected_words_features = [x[:-1] for x in selected_words_features.split(',')]
        if selected_words_features:
            if len(selected_words_features) == 1 and selected_words_features[0].find(':') < 0:
                selected_words_features = ''
            
        if len(exact_word_search) > 0:
            if lemma == "true":
                token = []
                token.append(exact_word_search)
                user_input_lemma = lemmatizer.lemmatize(token)[0][1]

            if stem == "true":
                user_input_stem = lat.stem(exact_word_search)

        if selected_tab == "CorporaText":
            if (len(author.strip()) > 0 and len(corporatext.strip()) ):
                cltk_doc_object = pps.get_doc_content(author.lower(), corporatext.lower())
                #rawdata = pps.get_raw_content(author,corporatext)
            else: return ""

        elif selected_tab == "UserEnteredEnterText":
            if len(selected_tab) > 0:
                content = request.form.get('user_entered_text');
                corporaText = bc.apply_cltk(content)

                cltk_doc_object = cltk_nlp.analyze(text=corporaText)
                #rawdata = cltk_doc_object.raw
            else: return ""

        elif selected_tab == "UploadRawFile":
            content = request.files['file'].read().decode("utf-8")
            if (len(content) > 0): 
                corporaText = bc.apply_cltk(content)
                cltk_doc_object = cltk_nlp.analyze(text=corporaText)
                #rawdata = cltk_doc_object.raw
            else: return ""
        
        print('Looping thru data.')
        new_class_name = ''   
        sentence_index = 0 
        tot_words = 0
        tot_words_found = 0

        for i in cltk_doc_object.sentences:
            ai_data_html = ''
            lemma_val = ''
            stem_val = ''
            sentence_index+=1
            list_of_matched_words = pos.search_word_pattern(i, exact_word_search.lower().split())
            
            for x in i.words:
                wordstring = x.string.strip()
                wordstring = utils.clean_text(wordstring)
                if len(wordstring) < 1:
                    continue

                if remove_words_chk == "true" and wordstring in stopwordlist:
                    continue      

                tot_words += 1
                wordfeatures, wrd_feature_dict = utils.get_word_features(x)
                wordpos = utils.ReplacePunctToNA(wordstring, x.upos.strip())
                
                try:
                    stem_val = x.stem
                except: pass

                try:
                    lemma_val = (lemmatizer.lemmatize([wordstring.lower()])[0][1]).capitalize()
                except: pass

                if user_selected_top_tab == 'wordSearch':
                    try:
                        new_class_name = ''
                        if lemma == "true" and user_input_lemma.strip().lower() == lemma_val.lower():
                            new_class_name = " marked"
                            tot_words_found +=1

              
                        if stem == "true" and user_input_stem.strip().lower() == stem_val.lower():
                            new_class_name = " marked"
                            tot_words_found +=1
                    
                        if len(exact_word_search) > 0:
                            if  x.index_token in list_of_matched_words:
                                if len(selected_words_features) > 0:
                                    found = pos.match_word_features(wordfeatures, selected_words_features)
                                    if found:
                                        new_class_name = " marked"
                                        tot_words_found +=1
                                else:
                                    new_class_name = " marked"
                                    tot_words_found +=1
                        else:        
                            found = pos.match_word_features(wordfeatures, selected_words_features)
                            if found:
                                new_class_name = " marked"
                                tot_words_found +=1
                    except Exception:
                        pass

                if macronize_chk == "true":
                    wordstring = macronizer._macronize_word( (str(x.string),str(x.pos)) )[2]
            
                tooltip_info_string = "<div class=\'aT0\'>"
                tooltip_info_string += "<div class=\'aT11\'><div class=\'aT2\'>" + "Pos" + "</div> <div  class=\'aT3\'>"  + wordpos + "</div></div>"
                tooltip_info_string +=  utils.get_value_from_dict(wrd_feature_dict,"Tense")
                tooltip_info_string +=  utils.get_value_from_dict(wrd_feature_dict,"Voice")
                tooltip_info_string +=  utils.get_value_from_dict(wrd_feature_dict,"Mood") 
                tooltip_info_string +=  utils.get_value_from_dict(wrd_feature_dict,"Person")
                tooltip_info_string +=  utils.get_value_from_dict(wrd_feature_dict,"Number")

                for ykey in wrd_feature_dict:
                    tooltip_info_string +=  utils.get_value_from_dict_no_pop(wrd_feature_dict,ykey)

                if stem_val is not None and  len(stem_val) > 0:
                    tooltip_info_string += "<div class=\'aT11\'><div class=\'aT2\'>" + "Stem" + "</div> <div  class=\'aT3\'>"  + stem_val + "</div></div>"
                
                if lemma_val is not None and len(lemma_val) > 0:
                    tooltip_info_string += "<div class=\'aT11\'><div class=\'aT2\'>" + "Lemma" + "</div> <div  class=\'aT3\'>"  + lemma_val + "</div></div>"

                tooltip_info_string += "</div>"
                tooltip_info_string = tooltip_info_string.replace('"','')

                #Get Rest of the Stuff from the Features after removing the above 
                if len(new_class_name) > 0:
                    ai_data_html += f'''<a data-toggle="popover" class="{new_class_name}" data-html="true" data-placement="bottom" data-content="{tooltip_info_string}"> {wordstring}</a> '''
                else:
                    if "." in wordstring or ";" in wordstring or "," in wordstring or  "?" in wordstring or ":" in wordstring:
                        if len(wordstring) > 1:
                            ai_data_html += f'''<a  data-toggle="popover" data-html="true" data-placement="bottom" data-content="{tooltip_info_string}"> {wordstring[:-1]}</a> '''
                            ai_data_html += f'''<a class="pu"> {wordstring[-1]}</a> '''
                        else:
                           ai_data_html += f'''<a class="pu"> {wordstring}</a> '''
                    else:
                        ai_data_html += f'''<a  data-toggle="popover" data-html="true" data-placement="bottom" data-content="{tooltip_info_string}"> {wordstring}</a> '''

            if (len(ai_data_html) > 0):
                global_ai_data += ai_data_html + "<br/></br>"

            stat_list['tot_words'] = tot_words
            stat_list['tot_sentences'] = sentence_index
            stat_list['tot_words_found'] =tot_words_found 
            tot_words_found_flag = False

            if tot_words_found:
                tot_words_found_flag = True   
            stat_list['tot_words_found_present'] = tot_words_found_flag 
    except Exception as e :
        print(e)
        global_ai_data = "Error Occured while processing data"
        pass

    return {'message': 'Created', 'code': 'SUCCESS',output_data_section:global_ai_data,
            #'rawdata': rawdata.strip().replace('\n\n\n', '\n').replace('\t', '\t'),
            #'rawdata': rawdata,
            'listOfLemmaStemMarkWords':ListOfWordsToMark, 'stat' : stat_list}

#Word Search
@app.route('/wordsearch/?word=WordFeaturesearch',methods=['GET', 'POST'])
def WordFeaturesearch():
    #For windows you need to use drive name [ex: F:/Example.pdf]
    if request.method == "GET":
        print(request.args.get('words'))
    return render_template('webpage.html', preprocessed_data = folder_filelist)

@app.route('/wordsearch/?words=ExactWordsearch',methods=['GET', 'POST'])
def ExactWordsearch():
    #For windows you need to use drive name [ex: F:/Example.pdf]
    if request.method == "GET":
        print(request.args.get('words'))
    return render_template('webpage.html', preprocessed_data = folder_filelist)

@app.route('/download')
def downloadFile():
    #For windows you need to use drive name [ex: F:/Example.pdf]
    return send_file(output_filename, as_attachment=True)

if __name__ == '__main__':
    #app.run(host = "0.0.0.0")
    app.run()