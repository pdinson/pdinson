from threading import Timer
import re
import subprocess

def get_word_meaning(word):
    anewword = ""
    ping = subprocess.Popen(["words.exe", word.strip().lower()], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    atext = ""
    kill = lambda process: process.kill()
    my_timer = Timer(5, kill, [ping])
    
    try:
        my_timer.start()
        atext = ping.communicate()[0].decode("utf-8")
    finally:
        my_timer.cancel()

    theoutput = re.split(r"[~\r\n]+", atext)

    for xp in theoutput:
        axword = re.sub(r"\[.+?\]", "", xp)

        if len(axword.strip()) > 0:
            anewword += "<div class='aiw'>" + str(axword).capitalize() + "</div>"

        # if len(xp.strip()) > 0:
        #     if re.search(r"\[d", xp.lower()) or re.search(r"\[e", xp.lower()) or re.search(r"\[x", xp.lower()) or re.search(r"\[f", xp.lower()) or re.search(r"\[g", xp.lower()):
        #         if re.search(r"lesser", xp.lower()):
        #             anewword += "Less Known: "
        #     else:
        #         if xp.find("UNKNOWN") > 0:
        #             break
        #         if  xp.find("RETURN") > 0 or xp.strip().lower() == anewword.strip().lower() :
        #             z=1
        #         else:
        #             xp = xp.replace("*", "")
        #             if xp.find("render by"):
        #                 xp = xp.replace("An internal 'h' might be rendered by ''","")
        #                 if len(xp) > 0:
        #                     anewword += xp.replace('/', ', ').capitalize() + "<br/>"
 
    anewword = re.sub(r"\[.+?\]", "", anewword)

    #anewword = re.sub("\[\D*\]", "", anewword)
    return anewword.capitalize()
